   <!-- /.row -->
          
                     
            <div class="row">
                 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3><b>  Mission and Vision</b>
                           </h3>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>
                               <h1> VISION</h1>

                                    The Premier University in historic Cavite globally recognized for excellence in character development, academics, research, innovation and sustainable community engagement.



                                     

                                   <h1>  MISSION</h1>

                                    Cavite State University shall provide excellent, equitable and relevant educational opportunities in the arts, sciences and technology through quality instruction and responsive research and development activities. It shall produce professional, skilled and morally upright individuals for global competitiveness.

                                     

                                   <h1> Objectives </h1>
                                   <ul>
                                    <li>In addition to, and in support of its mission and policies embodied in the charter, the University shall: </li>
                                    <li>provide a general education program that will promote national identity, cultural consciousness, moral integrity and spiritual vigor; </li>
                                    <li>train the nation's manpower in the skills required by the national development;</li>
                                    <li>develop professions that will provide leadership for the nation; and</li>
                                    <li>advance knowledge through research work and apply new knowledge for improving the quality of human life and responding effectively to changing societal needs and conditions.</li>
                                    <li>Apply acknowledge and honor excellence among its internal and external stakeholders, institutional partners country-wide and worldwide.</li>
                                    <li>Deeply cultivate and develop the essentiality and continuous relevant research and extension activities among its personnel and students to promote innovations, inventions and novelties.</li>
                                    <li>Collectively strive and sustain the establishment of Green Valley College Foundation Inc. as a world-class institution from good to great and built to last.</li>
                                   </ul>
                                </p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
           